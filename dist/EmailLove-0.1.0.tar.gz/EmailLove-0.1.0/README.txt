===========
Email Love
===========

Email Love allows you to quickly swap email providers by providing a generic set of api calls from multiple email providers
